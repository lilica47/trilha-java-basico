public interface AparelhoTelefonico {
    public void ligar();
    public void atender();
    public void iniciarCorreioVoz();
}
