public interface Navegador {
    public void exibirPagina();
    public void adicionarNovaAba();
    public void atualizarPagina();
}
